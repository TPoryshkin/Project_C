﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Program
{
    private static DigitalLibrary library = new DigitalLibrary("Цифрова бібліотека Університету");

    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.InputEncoding = Encoding.UTF8;

        //6 Конкретні реалізації - ініціалізація тестовими даними
        InitializeSampleData();

        Console.WriteLine("=== ЦИФРОВА БІБЛІОТЕКА ===");

        bool exit = false;
        while (!exit)
        {
            //8 Логічне меню додатка
            DisplayMenu();

            var choice = Console.ReadLine();
            switch (choice)
            {
                case "1": AddNewBook(); break;
                case "2": AddNewMagazine(); break;
                case "3": RegisterNewUser(); break;
                case "4": DisplayAllItems(); break;
                case "5": PrintAllItems(); break;
                case "6": ShowSortedBooks(); break;
                case "7": SearchBooksByAuthor(); break;
                case "8": ManageUserBooks(); break;
                case "9": ShowStatistics(); break;
                case "10": DemonstratePolymorphism(); break;
                case "0": exit = true; break;
                default: ShowInvalidChoice(); break;
            }
        }

        Console.WriteLine("Дякуємо за використання цифрової бібліотеки!");
    }

    static void DisplayMenu()
    {
        Console.WriteLine("\n=== МЕНЮ ===");
        Console.WriteLine("1. Додати нову книгу");
        Console.WriteLine("2. Додати новий журнал");
        Console.WriteLine("3. Зареєструвати нового користувача");
        Console.WriteLine("4. Показати всі елементи (коротка інформація)");
        Console.WriteLine("5. Надрукувати всі елементи (детальна інформація)");
        Console.WriteLine("6. Показати відсортовані книги");
        Console.WriteLine("7. Пошук книг за автором");
        Console.WriteLine("8. Керування книгами користувача");
        Console.WriteLine("9. Статистика бібліотеки");
        Console.WriteLine("10. Демонстрація поліморфізму");
        Console.WriteLine("0. Вийти");
        Console.Write("Оберіть опцію: ");
    }

    static void InitializeSampleData()
    {
        //6 Конкретні реалізації - створення тестових даних
        var author1 = new Author("Джоан Роулінг", "Велика Британія");
        var author2 = new Author("Джордж Орвелл", "Велика Британія");
        var author3 = new Author("Айзек Азімов", "США");

        library.AddAuthor(author1);
        library.AddAuthor(author2);
        library.AddAuthor(author3);

        // 3 Абстрактний клас - створення об'єктів похідних класів
        library.AddBook(new Book("978-0545010221", "Гаррі Поттер і філософський камінь",
            new BookDetails(320, "Фентезі", new DateTime(1997, 6, 26)), author1));

        library.AddBook(new Book("978-0451524935", "1984",
            new BookDetails(328, "Антиутопія", new DateTime(1949, 6, 8)), author2));

        library.AddBook(new Book("978-0553293357", "Я, робот",
            new BookDetails(253, "Наукова фантастика", new DateTime(1950, 12, 2)), author3));

        // 3 Абстрактний клас - створення об'єкта другого похідного класу
        library.AddMagazine(new Magazine("ISSN-1234", "Наука сьогодні", "2023-03",
            new DateTime(2023, 3, 15), "Наукове видавництво"));

        library.AddMagazine(new Magazine("ISSN-5678", "Технології майбутнього", "2023-02",
            new DateTime(2023, 2, 10), "Технології"));

        // 6 Конкретні реалізації - реєстрація користувачів
        library.RegisterUser(new LibraryUser("U001", "Іван Петренко"));
        library.RegisterUser(new LibraryUser("U002", "Марія Коваленко"));

        Console.WriteLine("Тестові дані успішно завантажені!");
    }

    static void AddNewBook()
    {
        Console.WriteLine("\n=== ДОДАВАННЯ НОВОЇ КНИГИ ===");

        try
        {
            Console.Write("ISBN: ");
            string isbn = Console.ReadLine();

            Console.Write("Назва: ");
            string title = Console.ReadLine();

            Console.Write("Кількість сторінок: ");
            int pages = int.Parse(Console.ReadLine());

            Console.Write("Жанр: ");
            string genre = Console.ReadLine();

            Console.Write("Ім'я автора: ");
            string authorName = Console.ReadLine();

            Console.Write("Країна автора: ");
            string country = Console.ReadLine();

            var author = new Author(authorName, country);

            //1 та 2 Реалізація інтерфейсів .NET - створення книги, яка реалізує кілька інтерфейсів
            var book = new Book(isbn, title, new BookDetails(pages, genre, DateTime.Now), author);

            library.AddBook(book);
            Console.WriteLine($"Книга '{title}' успішно додана!");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Помилка при додаванні книги: {ex.Message}");
        }
    }

    static void AddNewMagazine()
    {
        Console.WriteLine("\n=== ДОДАВАННЯ НОВОГО ЖУРНАЛУ ===");

        try
        {
            Console.Write("ISSN: ");
            string issn = Console.ReadLine();

            Console.Write("Назва: ");
            string title = Console.ReadLine();

            Console.Write("Номер випуску: ");
            string issue = Console.ReadLine();

            Console.Write("Видавець: ");
            string publisher = Console.ReadLine();

            // 3 Абстрактний клас - створення об'єкта похідного класу
            var magazine = new Magazine(issn, title, issue, DateTime.Now, publisher);
            library.AddMagazine(magazine);
            Console.WriteLine($"Журнал '{title}' успішно доданий!");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Помилка при додаванні журналу: {ex.Message}");
        }
    }

    static void RegisterNewUser()
    {
        Console.WriteLine("\n=== РЕЄСТРАЦІЯ НОВОГО КОРИСТУВАЧА ===");

        try
        {
            Console.Write("ID користувача: ");
            string userId = Console.ReadLine();

            Console.Write("Повне ім'я: ");
            string fullName = Console.ReadLine();

            var user = new LibraryUser(userId, fullName);
            library.RegisterUser(user);
            Console.WriteLine($"Користувач {fullName} успішно зареєстрований!");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Помилка при реєстрації користувача: {ex.Message}");
        }
    }

    static void DisplayAllItems()
    {
        //4 Поліморфізм через абстрактний клас - виклик методу для всіх елементів
        library.DisplayAllItems();
    }

    static void PrintAllItems()
    {
        // 4 Поліморфізм через інтерфейс - виклик методу для всіх об'єктів, що реалізують IPrintable
        library.PrintAllPrintableItems();
    }

    static void ShowSortedBooks()
    {
        Console.WriteLine("\n=== ВІДСОРТОВАНІ КНИГИ ЗА НАЗВОЮ ===");

        //1 Використання інтерфейсу IComparable для сортування
        var sortedBooks = library.GetSortedBooks();

        if (sortedBooks.Count == 0)
        {
            Console.WriteLine("В бібліотеці немає книг");
            return;
        }

        foreach (var book in sortedBooks)
        {
            Console.WriteLine($"- {book.Title} (автор: {book.Author?.Name})");
        }
    }

    static void SearchBooksByAuthor()
    {
        Console.Write("\nВведіть ім'я автора для пошуку: ");
        string authorName = Console.ReadLine();

        var books = library.FindBooksByAuthor(authorName);

        Console.WriteLine($"\n=== РЕЗУЛЬТАТИ ПОШУКУ ДЛЯ '{authorName}' ===");
        if (books.Count == 0)
        {
            Console.WriteLine("Книги не знайдено");
            return;
        }

        foreach (var book in books)
        {
            Console.WriteLine($"- {book.Title} (ISBN: {book.ItemId})");
        }
    }

    static void ManageUserBooks()
    {
        if (library.Users.Count == 0)
        {
            Console.WriteLine("Немає зареєстрованих користувачів");
            return;
        }

        Console.WriteLine("\n=== КЕРУВАННЯ КНИГАМИ КОРИСТУВАЧА ===");
        Console.WriteLine("Оберіть користувача:");

        for (int i = 0; i < library.Users.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {library.Users[i]}");
        }

        try
        {
            int userIndex = int.Parse(Console.ReadLine()) - 1;
            if (userIndex < 0 || userIndex >= library.Users.Count)
            {
                Console.WriteLine("Невірний номер користувача");
                return;
            }

            var user = library.Users[userIndex];

            Console.WriteLine($"\nОбрано: {user.FullName}");
            Console.WriteLine("1. Взяти книгу");
            Console.WriteLine("2. Повернути книгу");
            Console.WriteLine("3. Показати взяті книги");

            var choice = Console.ReadLine();
            switch (choice)
            {
                case "1": BorrowBookForUser(user); break;
                case "2": ReturnBookForUser(user); break;
                case "3": user.ShowBorrowedBooks(); break;
                default: Console.WriteLine("Невірний вибір"); break;
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Помилка: {ex.Message}");
        }
    }

    static void BorrowBookForUser(LibraryUser user)
    {
        var books = library.Items.OfType<Book>().ToList();
        if (books.Count == 0)
        {
            Console.WriteLine("В бібліотеці немає книг");
            return;
        }

        Console.WriteLine("\nОберіть книгу для взяття:");
        for (int i = 0; i < books.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {books[i].Title}");
        }

        try
        {
            int bookIndex = int.Parse(Console.ReadLine()) - 1;
            if (bookIndex < 0 || bookIndex >= books.Count)
            {
                Console.WriteLine("Невірний номер книги");
                return;
            }

            user.BorrowBook(books[bookIndex]);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Помилка: {ex.Message}");
        }
    }

    static void ReturnBookForUser(LibraryUser user)
    {
        if (user.BorrowedBooks.Count == 0)
        {
            Console.WriteLine("Користувач не має взятих книг");
            return;
        }

        Console.WriteLine("\nОберіть книгу для повернення:");
        for (int i = 0; i < user.BorrowedBooks.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {user.BorrowedBooks[i].Title}");
        }

        try
        {
            int bookIndex = int.Parse(Console.ReadLine()) - 1;
            if (bookIndex < 0 || bookIndex >= user.BorrowedBooks.Count)
            {
                Console.WriteLine("Невірний номер книги");
                return;
            }

            user.ReturnBook(user.BorrowedBooks[bookIndex]);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Помилка: {ex.Message}");
        }
    }

    static void ShowStatistics()
    {
        library.ShowStatistics();
    }

    static void DemonstratePolymorphism()
    {
        Console.WriteLine("\n=== ДЕМОНСТРАЦІЯ ПОЛІМОРФІЗМУ ===");

        // 4 Поліморфізм через абстрактний клас
        Console.WriteLine("\n1. Поліморфізм через абстрактний клас LibraryItem:");
        Console.WriteLine("Виклик методів GetItemType(), GetDescription(), GetFullInfo():");
        foreach (var item in library.Items)
        {
            // 4 Динамічне визначення типу об'єкта і виклик відповідної реалізації методу
            Console.WriteLine($"Тип: {item.GetItemType()}");
            Console.WriteLine($"Опис: {item.GetDescription()}");
            Console.WriteLine($"Повна інформація: {item.GetFullInfo()}");
            Console.WriteLine("---");
        }

        // 4 Поліморфізм через інтерфейс
        Console.WriteLine("\n2. Поліморфізм через інтерфейс IPrintable:");
        Console.WriteLine("Виклик методу Print() для всіх об'єктів, що реалізують IPrintable:");
        foreach (var printable in library.Items.OfType<IPrintable>())
        {
            // 4 Використання змінних типу інтерфейс, динамічне визначення типу об'єкта
            Console.WriteLine(printable.Print());
            Console.WriteLine("---");
        }

        // 1 Демонстрація інтерфейсу ICloneable
        Console.WriteLine("\n3. Демонстрація клонування (ICloneable):");
        if (library.Items.OfType<Book>().Any())
        {
            var originalBook = library.Items.OfType<Book>().First();
            var clonedBook = (Book)originalBook.Clone();
            clonedBook.Title = "КЛОН: " + clonedBook.Title;

            Console.WriteLine($"Оригінал: {originalBook.Title}");
            Console.WriteLine($"Клон: {clonedBook.Title}");
            Console.WriteLine("Клонування пройшло успішно - створено незалежну копію!");
        }

        // 1 Демонстрація інтерфейсу IComparable
        Console.WriteLine("\n4. Демонстрація сортування (IComparable):");
        var sortedBooks = library.GetSortedBooks();
        Console.WriteLine("Книги відсортовані за назвою:");
        foreach (var book in sortedBooks)
        {
            Console.WriteLine($"- {book.Title}");
        }

        // 4 Демонстрація перевизначення віртуального методу
        Console.WriteLine("\n5. Демонстрація перевизначення віртуального методу:");
        foreach (var item in library.Items)
        {
            Console.WriteLine($"Вирішення на етапі виконання: {item.GetFullInfo()}");
        }

        // 1 Демонстрація інтерфейсу IEnumerable
        Console.WriteLine("\n6. Демонстрація ітерації через IEnumerable:");
        Console.WriteLine("Всі книги в бібліотеці (через foreach):");
        foreach (var book in library)  
        {
            Console.WriteLine($"- {book.Title}");
        }
    }

    static void ShowInvalidChoice()
    {
        Console.WriteLine("Невірний вибір! Спробуйте ще раз.");
    }
}