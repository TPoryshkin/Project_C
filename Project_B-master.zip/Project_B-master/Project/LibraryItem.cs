﻿// 3 Абстрактний клас з абстрактними методами та властивостями
public abstract class LibraryItem
{
    // 3 Абстрактні властивості
    public abstract string ItemId { get; set; }
    public abstract string Title { get; set; }

    // 3 Абстрактні методи
    public abstract string GetDescription();
    public abstract string GetItemType();

    // 4 Віртуальний метод для демонстрації поліморфізму
    public virtual string GetFullInfo()
    {
        return $"{GetItemType()}: {Title} (ID: {ItemId})";
    }
}