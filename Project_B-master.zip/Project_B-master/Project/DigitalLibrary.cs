﻿public class DigitalLibrary : IEnumerable<Book>
{
    public string Name { get; set; }
    public List<LibraryItem> Items { get; set; }
    public List<Author> Authors { get; set; }
    public List<LibraryUser> Users { get; set; }

    public DigitalLibrary(string name)
    {
        Name = name;
        Items = new List<LibraryItem>();
        Authors = new List<Author>();
        Users = new List<LibraryUser>();
    }

    // Методи для додавання елементів
    public void AddBook(Book book)
    {
        Items.Add(book);
        if (book.Author != null && !Authors.Contains(book.Author))
        {
            Authors.Add(book.Author);
        }
    }

    public void AddMagazine(Magazine magazine)
    {
        Items.Add(magazine);
    }

    public void AddAuthor(Author author)
    {
        if (!Authors.Contains(author))
        {
            Authors.Add(author);
        }
    }

    public void RegisterUser(LibraryUser user)
    {
        if (!Users.Contains(user))
        {
            Users.Add(user);
        }
    }

    // Поліморфізм через абстрактний клас
    public void DisplayAllItems()
    {
        Console.WriteLine($"\n=== ВСІ ЕЛЕМЕНТИ БІБЛІОТЕКИ '{Name}' ===");
        foreach (var item in Items)
        {
            Console.WriteLine(item.GetFullInfo());
            Console.WriteLine("---");
        }
    }

    // Поліморфізм через інтерфейс
    public void PrintAllPrintableItems()
    {
        Console.WriteLine($"\n=== ДРУК УСІХ ЕЛЕМЕНТІВ ===");
        foreach (var printable in Items.OfType<IPrintable>())
        {
            Console.WriteLine(printable.Print());
            Console.WriteLine("---");
        }
    }

    // Сортування книг (використання IComparable)
    public List<Book> GetSortedBooks()
    {
        var books = Items.OfType<Book>().ToList();
        books.Sort();
        return books;
    }

    // Пошук книг за автором
    public List<Book> FindBooksByAuthor(string authorName)
    {
        return Items.OfType<Book>()
                   .Where(b => b.Author?.Name?.Contains(authorName, StringComparison.OrdinalIgnoreCase) == true)
                   .ToList();
    }

    // 1 Реалізація інтерфейсу .NET - IEnumerable<T>
    public IEnumerator<Book> GetEnumerator()
    {
        return Items.OfType<Book>().GetEnumerator();
    }

    System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
    {
        return GetEnumerator();
    }

    // Статистика
    public void ShowStatistics()
    {
        var books = Items.OfType<Book>().Count();
        var magazines = Items.OfType<Magazine>().Count();

        Console.WriteLine($"\n=== СТАТИСТИКА БІБЛІОТЕКИ ===");
        Console.WriteLine($"Кількість книг: {books}");
        Console.WriteLine($"Кількість журналів: {magazines}");
        Console.WriteLine($"Кількість авторів: {Authors.Count}");
        Console.WriteLine($"Кількість користувачів: {Users.Count}");
        Console.WriteLine($"Загальна кількість елементів: {Items.Count}");
    }
}