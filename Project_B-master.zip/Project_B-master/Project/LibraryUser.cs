﻿public class LibraryUser
{
    public string UserId { get; set; }
    public string FullName { get; set; }
    public List<Book> BorrowedBooks { get; set; }

    public LibraryUser(string userId, string fullName)
    {
        UserId = userId;
        FullName = fullName;
        BorrowedBooks = new List<Book>();
    }

    public void BorrowBook(Book book)
    {
        if (book != null && !BorrowedBooks.Contains(book))
        {
            BorrowedBooks.Add(book);
            Console.WriteLine($"{FullName} взяв(ла) книгу: '{book.Title}'");
        }
    }

    public void ReturnBook(Book book)
    {
        if (book != null && BorrowedBooks.Contains(book))
        {
            BorrowedBooks.Remove(book);
            Console.WriteLine($"{FullName} повернув(ла) книгу: '{book.Title}'");
        }
    }

    public void ShowBorrowedBooks()
    {
        Console.WriteLine($"\n=== КНИГИ, ВЗЯТІ {FullName.ToUpper()} ===");
        if (BorrowedBooks.Count == 0)
        {
            Console.WriteLine("Користувач не брав книг");
            return;
        }

        foreach (var book in BorrowedBooks)
        {
            Console.WriteLine($"- {book.Title} (ISBN: {book.ItemId})");
        }
    }

    public override string ToString() => $"{FullName} (ID: {UserId})";
}