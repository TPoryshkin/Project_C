# Цифрова бібліотека - Digital Library System

![.NET](https://img.shields.io/badge/.NET-6.0-purple)
![C#](https://img.shields.io/badge/C%23-10.0-blue)
![License](https://img.shields.io/badge/License-MIT-green)

##  Опис проекту

Цей проект реалізує систему управління цифровою бібліотекою, розроблену на мові C# з використанням принципів об'єктно-орієнтованого програмування. Система дозволяє ефективно керувати бібліотечним фондом, користувачами та процесами позичання книг.

##  Основні функції

- **Управління каталогом**: Додавання книг та журналів
-  **Управління користувачами**: Реєстрація та облік читачів
-  **Пошук та сортування**: Пошук книг за автором, сортування за назвою
-  **Статистика**: Детальна статистика бібліотечного фонду
-  **Друк інформації**: Форматований вивід інформації про ресурси
-  **Поліморфізм**: Демонстрація різних видів поліморфізму в OOP

##  Архітектура проекту

### Основні класи та інтерфейси

- **`LibraryItem`** (абстрактний клас) - базовий клас для всіх елементів бібліотеки
- **`Book`** - клас книги, реалізує інтерфейси `IPrintable`, `ICloneable`, `IComparable<Book>`
- **`Magazine`** - клас журналу, реалізує інтерфейс `IPrintable`
- **`DigitalLibrary`** - основний клас бібліотеки, реалізує `IEnumerable<Book>`
- **`Author`** - клас автора
- **`LibraryUser`** - клас користувача бібліотеки
- **`BookDetails`** - клас деталей книги

### Діаграма класів
DigitalLibrary
├── LibraryItem (abstract)
│ ├── Book (IPrintable, ICloneable, IComparable<Book>)
│ └── Magazine (IPrintable)
├── Author
├── LibraryUser
├── BookDetails
└── DigitalLibrary (IEnumerable<Book>)

text

##  Вимоги до системи

- **.NET 6.0** або новішої версії
- **Visual Studio 2022** або **Visual Studio Code**
- **MSTest** для запуску тестів

##  Інструкція зі встановлення

1. **Клонування репозиторію**
   ```bash
   git clone https://github.com/your-username/digital-library.git
   cd digital-library
Відкриття проекту

Відкрити DigitalLibrary.sln у Visual Studio

Або використовувати Visual Studio Code з розширенням C#

Відновлення залежностей

bash
dotnet restore
Збірка проекту

bash
dotnet build
 Використання програми
Запуск програми
bash
dotnet run --project DigitalLibrary
Меню програми
text
=== ЦИФРОВА БІБЛІОТЕКА ===

=== МЕНЮ ===
1. Додати нову книгу
2. Додати новий журнал
3. Зареєструвати нового користувача
4. Показати всі елементи (коротка інформація)
5. Надрукувати всі елементи (детальна інформація)
6. Показати відсортовані книги
7. Пошук книг за автором
8. Керування книгами користувача
9. Статистика бібліотеки
10. Демонстрація поліморфізму
0. Вийти
Оберіть опцію:
 Тестування
Запуск unit-тестів
bash
dotnet test
Покриття тестами
 Тести додавання книг та журналів

 Тести роботи з користувачами

Тести пошуку та сортування

 Тести поліморфних методів

 Тести клонування та порівняння

🔧 Технічні особливості
Реалізація поліморфізму
1. Поліморфізм через абстрактний клас:

csharp
public abstract class LibraryItem
{
    public virtual string GetFullInfo() { /* базова реалізація */ }
}

public class Book : LibraryItem
{
    public override string GetFullInfo() { /* спеціалізована реалізація */ }
}
2. Поліморфізм через інтерфейси:

csharp
public interface IPrintable
{
    string Print();
}

public class Book : IPrintable
{
    public string Print() { /* реалізація для книги */ }
}

public class Magazine : IPrintable
{
    public string Print() { /* реалізація для журналу */ }
}
Використання інтерфейсів .NET
ICloneable - для створення копій об'єктів Book

IComparable<Book> - для сортування книг за назвою

IEnumerable<Book> - для ітерації по книгах у бібліотеці

 Структура проекту
text
DigitalLibrary/
├── Program.cs                 # Головна програма з меню
├── DigitalLibrary.cs          # Основний клас бібліотеки
├── LibraryItem.cs             # Абстрактний базовий клас
├── Book.cs                    # Клас книги
├── Magazine.cs                # Клас журналу
├── Author.cs                  # Клас автора
├── LibraryUser.cs             # Клас користувача
├── BookDetails.cs             # Клас деталей книги
├── IPrintable.cs              # Інтерфейс для друкованих об'єктів
├── DigitalLibraryTests.cs     # Unit-тести
└── DigitalLibrary.csproj      # Файл проекту
 Розробка
Додавання нових функцій
Для додавання нового типу елементів бібліотеки:

Успадкувати від LibraryItem

Реалізувати необхідні інтерфейси

Для розширення функціоналу:

Додати методи в DigitalLibrary

Оновити меню в Program.cs

Додати відповідні тести
